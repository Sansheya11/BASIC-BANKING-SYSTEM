<?php

	$conn = mysqli_connect('localhost','id17191526_sansheya','Sansheyabaskar@11','id17191526_basicbankingsystem');

	if(!$conn){
		die("Could not connect to the database due to the following error --> ".mysqli_connect_error());
	}

?>