

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";





CREATE TABLE `transaction` (
  `sno` int(3) NOT NULL,
  `sender` text NOT NULL,
  `receiver` text NOT NULL,
  `balance` int(8) NOT NULL,
  `datetime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------



CREATE TABLE `users` (
  `id` int(3) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(30) NOT NULL,
  `balance` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



INSERT INTO `users` (`id`, `name`, `email`, `balance`) VALUES
(1, 'Sans', 'sans@gmail.com', 50000),
(2, 'Sham', 'sham@gmail.com', 30000),
(3, 'Liviya', 'liviya@gmail.com', 40000),
(4, 'Rohan', 'rohan@gmail.com', 50000),
(5, 'Dhiviya', 'diviya@gmail.com', 40000),
(6, 'Andrew', 'andrew@gmail.com', 30000),
(7, 'Sathish', 'sathish@gmail.com', 50000),
(8, 'Nishaanth', 'nishaath@gmail.com', 40000),
(9, 'Bharath', 'bharath@gmail.com', 30000),
(10, 'Lalshmi', 'lakshmiu@gmail.com', 50000);



ALTER TABLE `transaction`
  ADD PRIMARY KEY (`sno`);


ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `transaction`
  MODIFY `sno` int(3) NOT NULL AUTO_INCREMENT;


ALTER TABLE `users`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT;
COMMIT;


